package Model;

import java.io.Serializable;
import java.sql.Date;
import java.util.List;




import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GenerationType;
import javax.persistence.Transient;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="food")
public class Food implements Serializable{
	
	public Food(String foodname2,Integer quantity2, Integer cals, Integer tcals,java.util.Date date2) {
		
		this.foodname=foodname2;
		this.quantity=quantity2;
		this.calories=cals;
		this.totalCalories=tcals;
		this.date=date2;
	}

	public Food() {
		
	}

	

	public Food(Food testA) {
		this.foodname=testA.foodname;
		this.quantity=testA.quantity;
		this.calories=testA.calories;
		this.totalCalories=testA.totalCalories;
		this.date=testA.date;
		
	}

	public Food(String string, Integer integer) {
		this.foodname=string;
		this.quantity=integer;
	}

	public Integer getFoodId() {
		return foodId;
	}

	public void setFoodId(Integer foodId) {
		this.foodId = foodId;
	}

	public String getFoodname() {
		return foodname;
	}

	public void setFoodname(String foodname) {
		this.foodname = foodname;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Integer getCalories() {
		return calories;
	}

	public void setCalories(Integer calories) {
		this.calories = calories;
	}

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="foodId")
	
	private Integer foodId;
	
	@Column(name="foodname")
	private String foodname;
	
	@Column(name="quantity")
	private Integer quantity;
	
	@Column(name="calories")
	private Integer calories;
	
	@Column(name="totalcalories")
	private Integer totalCalories;

	@Column(name="dates")
	private java.util.Date date;
	
	@Transient
	private List<Food> foods;
	
	
	public List<Food> getFoods() {
		return foods;
	}

	public void setFoods(List<Food> foods) {
		this.foods = foods;
	}

	public java.util.Date getDate() {
		return date;
	}

	public void setDate(java.util.Date date) {
		this.date = date;
	}

	public Integer getTotalCalories() {
		
		return totalCalories;
	}

	public void setTotalCalories(Integer totalCalories) {
		this.totalCalories = totalCalories;
	}
}
