package Model;

import java.io.Serializable;

import java.util.List;





import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GenerationType;
import javax.persistence.Transient;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="calorie")
public class Calorie implements Serializable{
	
public Calorie() {
		
	}

    public Calorie(java.util.Date todaysDate, Integer totalCals) {
	this.tdate=todaysDate;
	
}

	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    @Column(name="id")
	private Integer id;
	
    @Column(name="tdate")
    private java.util.Date tdate;
    
    @Column(name="tcal")
    private Integer tcal;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public java.util.Date getTdate() {
		return tdate;
	}

	public void setTdate(java.util.Date tdate) {
		this.tdate = tdate;
	}

	public Integer getTcal() {
		return tcal;
	}

	public void setTcal(Integer tcal) {
		this.tcal = tcal;
	}
    
    
	
}
	
