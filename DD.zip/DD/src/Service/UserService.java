package Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Conjunction;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import Model.*;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service("userService")
@Transactional
public class UserService {
	
	@Resource(name="sessionFactory")
	private SessionFactory sessionFactory;
	
	
	public void saveFoodItem(Food fi){
		Session session = sessionFactory.getCurrentSession();
	
    	session.saveOrUpdate(fi);
		
	}
	
	
	public List<User> getAll(){
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery("FROM User");
		return query.list();
	}
	
	public User get(Integer userId){
		Session session = sessionFactory.getCurrentSession();
		return (User)session.get(User.class,userId);
	}
	
	public User getuserByName(String userName){
		Session session = sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(User.class);
		criteria.add(Restrictions.like("userName",userName));
		
		Object result = criteria.uniqueResult();
		User user = (User) result;
		
		return user;
	}
	
	public boolean validate(String userName,String password){
		
		Session session = sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(User.class);
		criteria.add(Restrictions.like("userName",userName));
		
		boolean flag = false;
		Object result = criteria.uniqueResult();
		if(result!=null){
			User user = (User) result;
			if(user.getPassword().equalsIgnoreCase(password)){
				flag = true;
			}
		}
		
		if(flag==true){
			return true;
		}
		else{
			return false;
		}
	}
	
	public void add(User user) {
		Session session = sessionFactory.getCurrentSession();
		session.save(user);
	}
	
	public void delete(Integer userId){
		Session session = sessionFactory.getCurrentSession();
		User user = (User)session.get(User.class,userId);
		session.delete(user);
	}

	public void edit(User user){
		Session session = sessionFactory.getCurrentSession();
		User user1 = (User)session.get(User.class,user.getUserId());
		
		user1.setUserName(user.getUserName());
		user1.setPassword(user.getPassword());
		
		session.save(user1);
	}

	public boolean searchFood(String foodname) {
		Session session = sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Food.class);
		criteria.add(Restrictions.like("foodname",foodname));
		
		boolean flag = false;
		List result = criteria.list();
		if(result!=null){
			
			   
				flag = true;
			
		}
		
		if(flag==true){
			return true;
		}
		else{
			return false;
		}
	}

	@SuppressWarnings("unchecked")
	public List<Food> getFood(String foodname) {
		
		Session session = sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Food.class);
		criteria.add(Restrictions.like("foodname",foodname));
		
		
		
		List<Food> result = criteria.list();
		
			return result;
			
		
		
	}
	public void saveFoodDiary(Food fs){
	Session session = sessionFactory.getCurrentSession();
	

	
		Food fw=new Food();
		fw.setFoodname(fs.getFoodname());
		fw.setQuantity(fs.getQuantity());
		fw.setCalories(fs.getCalories());
		fw.setTotalCalories(fs.getTotalCalories());
		fw.setDate(fs.getDate());
		
		if(fw.getDate()==Calendar.getInstance().getTime()){
		
		session.update(fw);
	}else{
		session.save(fw);
	}

	}
	
	
	
	
	@SuppressWarnings("unchecked")
	public List<Food> getFoodList(Food food) {
		
		Session session = sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Food.class);
		Integer foodId=food.getFoodId();
		criteria.add(Restrictions.like("foodId",foodId));
		
		
		
		List<Food> result = criteria.list();
		
			return result;
			
		
		
	}


	@SuppressWarnings("unchecked")
	public List<Food> searchFoodFromDB(Date date) {
	  	
		List<Food> listFoodDiary=null;
		try {
			
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(Food.class);
			Calendar calendar = Calendar.getInstance();
			calendar.set(Calendar.HOUR_OF_DAY, 0);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, 0);
			Date fromDate = calendar.getTime();
			
			Calendar calendar1=Calendar.getInstance();
			calendar1.set(Calendar.HOUR_OF_DAY, 23);
			calendar1.set(Calendar.MINUTE, 59);
			calendar1.set(Calendar.SECOND, 59);
			Date toDate = calendar1.getTime();
			
			criteria.add(Restrictions.between("date", fromDate, toDate));
			listFoodDiary=criteria.list();
			System.out.println("food diary list is:::" +listFoodDiary.toString());
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
		
		
		return listFoodDiary;
		
		
			
		
	}


	public String deleteUncheckedRecords(String lf) {
		Session session = sessionFactory.getCurrentSession();
		String ids = "(";
		
		
	
		String dsql = "Delete from Food f where f.foodId not in"+lf;
		System.out.println("mysql is "+dsql);
		
		Query query = session.createQuery(dsql);
		int y=query.executeUpdate();
		if(y==0){
			
			return "error";
		}else{
			System.out.println("records deleted");
			return "hi";
		}
	}


	public void saveTotalCalories(Calorie c) {
		Session session = sessionFactory.getCurrentSession();
		session.saveOrUpdate(c);
		
	}
		
	}
	
	
	



