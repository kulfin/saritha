package Controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;


import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Model.*;
import Dto.*;
import Service.*;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;


@Controller
@RequestMapping("/record")
public class MainController {
	
	
	
	@Resource(name="userService")
	private UserService userService; 
	
	@Resource(name="roleService")
	private RoleService roleService;
	
	@RequestMapping(value="/login")
	public String GetFront(Model model){
		return "login";
	}
	
	/*
	@RequestMapping(value="/admin")
	public String Front1(Model model){
		return "admin";
	}
	
	@RequestMapping(value="/Hello")
	public String Front2(Model model){
		return "Hello";
	}
	
	@RequestMapping(value="/error")
	public String Front3(Model model){
		return "error";
	}
	*/
	
	@RequestMapping(value="/authenticate",method = RequestMethod.POST)
    public String authenticate(@RequestParam("uname")String userName,@RequestParam("pass")String password,
    		HttpSession session,HttpServletRequest request,Model model){
    	
    	boolean success = userService.validate(userName,password);
    	User user = userService.getuserByName(userName);
    	Set<Role> roles = user.getRole();
    	String role = null;
    	
    	for (Role role1: roles) {   		
    		if(role1.getRoleName().equalsIgnoreCase("admin")){
    			role = "admin";
    		}    		
    	}
    	
    	if(success){
    		session = request.getSession();
    		session.setAttribute("users",userName);
    		session.setAttribute("role", roles);
    		return "Hello";
    	}
    	else{
    		return "error";
    	}
    
    }
	
	@RequestMapping(value="/foodsearch",method = RequestMethod.POST)
    public String SearchForFood(@RequestParam("foodname")String foodname,HttpSession session,HttpServletRequest request,Model model){
    	System.out.println("coming to food search method");
    	boolean success = userService.searchFood(foodname);
    	ArrayList<Food> foodClass=(ArrayList<Food>)userService.getFood(foodname);
    	
    	
    	if(success){
    		session = request.getSession(true);
    		 session.setAttribute("foodClass",foodClass);
    		
    	    
    		return "Hello";
    	}
    	else{
    		return "error";
    	}
    
    }
	
	
	
	@RequestMapping(value="/save",method = RequestMethod.POST)
    public String SaveFoodItems(HttpServletRequest request, HttpServletResponse response,HttpSession session){
		Food fd=null;
		String foodname=request.getParameter("foodnames");
		session.setAttribute("foodname", foodname);
		
		List<Food> l=new ArrayList<Food>();
	    l=userService.getFood(foodname);
		
		int s=l.size();
		System.out.println("size of list is::" +s);
		for(int i=1; i<=s;i++){
		
    	String fnm=(String)session.getAttribute("foodname");
    	Integer quanty = Integer.parseInt(request.getParameter("qty"));
    	Integer cals=Integer.parseInt(request.getParameter("tCalories"));
    	Integer totalCalories=quanty*cals;
    	
    	
    	Date date=Calendar.getInstance().getTime();
    	
        fd=new Food(fnm,quanty,cals,totalCalories,date);
        userService.saveFoodItem(fd);
		}
		
		
    	return "hi";
    }
	
	
	
	
	
	
	@RequestMapping(value="/saveFinalFoodDiary",method = RequestMethod.POST)
    public String SaveFoodItemsList(HttpServletRequest request,HttpSession session){
		Date dates=Calendar.getInstance().getTime();
		List<Food> entireFoodList=userService.searchFoodFromDB(dates);
		String checkedFood[]=request.getParameterValues("fid");
		List checkedStringList=Arrays.asList(checkedFood);
		
		Food foods=null;
		 System.out.println("Selected Foods counteR " +checkedStringList.size());
		 String fid[] = null;
		 String idmerge = "(";
		 Integer totalCals=0;
		for(int i=0; i<checkedStringList.size(); i++) 
		{ 
	     
			
			
			
			 fid =request.getParameterValues("fid");
	        int fid1=Integer.parseInt(fid[i]);
	        
	        idmerge = idmerge + fid1 + ",";
	       System.out.println("checked id value is:::" +fid1);
			
			String name[]=request.getParameterValues("foodnames");
	        String names=name[i];
	        System.out.println("food name is:::" +names);
	    
	    
	    
	    String quantity[]=request.getParameterValues("qty");
		Integer quantities = Integer.parseInt(quantity[i]); 
		 System.out.println("quantity is:::" +quantities);
		 
		 
		 

		String cals[]=request.getParameterValues("tCalories");
		Integer calories=Integer.parseInt(cals[i]);
		Integer totalCalories=quantities*calories;
		totalCals=totalCals+totalCalories;
		
		} 
		idmerge = idmerge + "0)";
		System.out.println("total calories of all food items is:::" +totalCals);
		userService.deleteUncheckedRecords(idmerge);
		 System.out.println("id  list is :::" +idmerge);
		 totalCals=totalCals+0;
		session.setAttribute("totalCals", totalCals);
		
		Date todaysDate=Calendar.getInstance().getTime();
		Calorie cals=new Calorie(todaysDate,totalCals);
		
		userService.saveTotalCalories(cals);
		
    	return "hi";
    }
	
	
	
	
	
	
	
	@RequestMapping(value="/saveFoodDiary",method = RequestMethod.POST)
    public String SaveFoodItemList(HttpServletRequest request,HttpSession session){
		
		String values[]=request.getParameterValues("checkboxgroup");
		List foodList=Arrays.asList(values);
		String name[]=request.getParameterValues("foodnames");
		String quantity[]=request.getParameterValues("qty");
		
		Integer[] qty = new Integer[quantity.length]; 
		for(int i=0; i<foodList.size(); i++) 
		{ 
	    name=request.getParameterValues("foodnames");
	    String names=name[i];
	    System.out.println("food name is:::" +names);
		Integer quantities = Integer.parseInt(quantity[i]); 
		 System.out.println("quantity is:::" +quantities);
		String cals[]=request.getParameterValues("tCalories");
		Integer calories=Integer.parseInt(cals[i]);
		Integer totalCalories=quantities*calories;
		Date date=Calendar.getInstance().getTime();
		Food foods=new Food(names,quantities,calories,totalCalories,date);
		Integer tcal=totalCalories;
		tcal+=tcal;
		request.getSession().setAttribute("tcal", tcal);
		
		userService.saveFoodDiary(foods);
		
		
		
		} 
		
    	return "hi";
    }
	
	
	@RequestMapping(value="/showFoods",method = RequestMethod.POST)
    public String ShowFoodList(HttpServletRequest request,HttpSession session){
		String values[]=request.getParameterValues("checkboxgroup");
		List foodList=Arrays.asList(values);
		String name[]=request.getParameterValues("foodnames");
		String quantity[]=request.getParameterValues("qty");
		Integer totalCals=0;
		Integer[] qty = new Integer[quantity.length]; 
		for(int i=0; i<foodList.size(); i++) 
		{ 
	    name=request.getParameterValues("foodnames");
	    String names=name[i];
	    System.out.println("food name is:::" +names);
		Integer quantities = Integer.parseInt(quantity[i]); 
		 System.out.println("quantity is:::" +quantities);
		String cals[]=request.getParameterValues("tCalories");
		Integer calories=Integer.parseInt(cals[i]);
		Integer totalCalories=quantities*calories;
		
		totalCals = totalCals + totalCalories; 
		Date date=Calendar.getInstance().getTime();
		Food foods=new Food(names,quantities,calories,totalCalories,date);
		userService.saveFoodDiary(foods);
		Date dates=Calendar.getInstance().getTime();
		List<Food> entireFoodList=userService.searchFoodFromDB(dates);
		System.out.println("entire food list is:::" +entireFoodList.toString());
		session=request.getSession(true);
		session.setAttribute("entireFoodList", entireFoodList);
		
		session.setAttribute("totalCals", totalCals);
		
		String tcal=request.getParameter("totalCal");
		System.out.println("total calorijghjkhgjkyjkhk is::" +tcal);
		Date todaysDate=Calendar.getInstance().getTime();
		// Calorie cals1=new Calorie(todaysDate,tcal);
		
	//	userService.saveTotalCalories(cals1);
		
		} 
		
		System.out.println("total calories added to diary is:::" +totalCals);
			
    	return "foodDiary";
    }
	
	
	
	
	
	
	
	
	
	
/*	@RequestMapping(value="/showFoods",method = RequestMethod.POST)
    public String ShowFoodList(HttpServletRequest request,HttpSession session){
		
		String values[]=request.getParameterValues("checkboxgroup");
		List foodList=Arrays.asList(values);
		String name[]=request.getParameterValues("foodnames");
		String quantity[]=request.getParameterValues("qty");
		Food foods=null;
		Integer[] qty = new Integer[quantity.length]; 
		for(int i=0; i<foodList.size(); i++) 
		{ 
	    name=request.getParameterValues("foodnames");
	    String names=name[i];
	    System.out.println("food name is:::" +names);
		Integer quantities = Integer.parseInt(quantity[i]); 
		 System.out.println("quantity is:::" +quantities);
		String cals[]=request.getParameterValues("tCalories");
		 System.out.println("cals is:::" +cals);
		Integer calories=Integer.parseInt(cals[i]);
		 System.out.println("calories in int  is:::" +calories);
		Integer totalCalories=quantities*calories;
		 System.out.println("total cals is:::" +totalCalories);
		Date date=Calendar.getInstance().getTime();
		 System.out.println("date is:::" +date);
	    foods=new Food(names,quantities,calories,totalCalories,date);
	    System.out.println("date is:::" +date);
	    List<ArrayList<Food>> foodsList = new ArrayList<ArrayList<Food>>();
	   
		ArrayList<Food> lf=(ArrayList<Food>)session.getAttribute("foodClass");
		 System.out.println("FOOD LIST lf is:::" +lf.toString());
		 
		
		session=request.getSession(true);
		session.setAttribute("lf",lf);
		 System.out.println("lf after addition is:::" +lf.toString());
		 foodsList.add(lf);
		
		 
		
		
		session.setAttribute("foodsList", foodsList);
		
		} 
			
    	return "foodDiary";
    }
	*/
	
	
	
	
	
	/*
	@RequestMapping(value="/admin")
	public String admin(HttpSession session,HttpServletRequest request,Model model){
		
		HttpSession session3 = request.getSession(false);
		Set<Role> roles = (Set<Role>) session3.getAttribute("role");
		boolean permit = false;
		
		for (Role role1: roles) {   		
    		if(role1.getRoleName().equalsIgnoreCase("admin")){
    			permit = true;
    		}    		
    	}
		
		if(permit){
			return "admin";
		}
		else{
			return "error";
		}
	}
	*/
	
	@RequestMapping(value="/Logout")
	public String Logout(HttpSession session,HttpServletRequest request,Model model){
		HttpSession session2 = request.getSession(false);
		session2.removeAttribute("users");
		session2.removeAttribute("role");
		if(session2!=null){
			session2.invalidate();
		}
		return "logout";
	}
    
	
	@RequestMapping(value = "/list", method = RequestMethod.GET)
    public String getRecords(Model model) {
    	
    	List<User> users = userService.getAll();
    	
    	List<UserDTO> userDTO = new ArrayList<UserDTO>();
    	
    	for (User user: users) {
    		UserDTO dto = new UserDTO();
    		
			dto.setUserId(user.getUserId());
			dto.setUserName(user.getUserName());
			dto.setPassword(user.getPassword());
			dto.setRole(roleService.getAll(user.getUserId()));
			
			userDTO.add(dto);
    	}
    	
    	model.addAttribute("users", userDTO);
		return "record";
	}
    
    @RequestMapping(value = "/add", method = RequestMethod.GET)
    public String getAdd(Model model) {
    	
    	model.addAttribute("userAttribute", new User());
    	
    	return "addUser";
	}
 
    
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public String postAdd(@ModelAttribute("userAttribute") User user) {
		
    	userService.add(user);
		return "redirect:/record/list";
	}
    
 
    @RequestMapping(value = "/delete", method = RequestMethod.GET)
    public String getDelete(@RequestParam("id") Integer userId) {
    	
		userService.delete(userId);
		return "redirect:/record/list";
	}
    
    @RequestMapping(value = "/edit", method = RequestMethod.GET)
    public String getEdit(@RequestParam("id") Integer userId, Model model) {
    	
    	User user1 = userService.get(userId);
    	model.addAttribute("userAttribute",user1);
    	
    	return "editUser";
	}
 
    @RequestMapping(value = "/edit", method = RequestMethod.POST)
    public String postEdit(@RequestParam("id") Integer userId, 
    						    @ModelAttribute("userAttribute") User user) {
		
		user.setUserId(userId);
		userService.edit(user);
		return "redirect:/record/list";
	}

}
